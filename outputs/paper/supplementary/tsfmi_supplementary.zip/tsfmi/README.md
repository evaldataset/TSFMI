# TSFMI: Anonymous Code Release (NeurIPS 2026 E&D Track)

This is the anonymized code/data artifact for the submission
**"TSFMI: A Baseline-Controlled Evaluation Protocol for Time-Series
Foundation Model Representations"** to the NeurIPS 2026 Evaluations &
Datasets Track.

The artefact contains:

- `src/`: 7 TSFM wrappers, 12 synthetic generators, probing & intervention library
- `scripts/`: extraction, canonical benchmark, baselines, LEACE/CKA/steering, paper-figure regeneration
- `tests/`: 170 automated tests (`make test`)
- `configs/`: per-experiment configuration references
- `LICENSE`: MIT (code) + pointers to original licenses for the public real-world datasets used
- `CROISSANT.json`: machine-readable dataset description (Croissant 1.0 + RAI fields)
- `Makefile`: one-line entrypoints for every reproducible target

## Quick reviewer reproduction (CPU, <10 min)

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pip install -e ".[dev]"
make smoke
```

`make smoke` reproduces one cell of the canonical baseline grid +
per-feature anomaly attribution + the test suite. No GPU required.

## Full reproduction (~48 A100-hours)

```bash
make extract-representations    # ~40h GPU, 7 models x 6 datasets
make reproduce-all              # baselines + canonical + figures + paper compile
```

## Validation

```bash
make test   # 170 tests
make lint   # ruff check
```

## Reproduce Main Pipeline

```bash
# 1. Extract representations
PYTHONPATH=. python scripts/extract_representations.py \
  --model moment --dataset synthetic_trend --layers all \
  --output_dir outputs/representations/

# 2. Train probes
PYTHONPATH=. python scripts/train_probe.py \
  --representations_dir outputs/representations/moment/synthetic_trend \
  --output_dir outputs/probes/moment_synthetic_trend_linear \
  --probe_type linear

# 3. Evaluate
PYTHONPATH=. python scripts/evaluate_probe.py \
  --probe_dir outputs/probes/moment_synthetic_trend_linear \
  --representations_dir outputs/representations/moment/synthetic_trend \
  --output_dir outputs/eval/moment_synthetic_trend_linear
```

## Additional Analyses

```bash
PYTHONPATH=. python scripts/run_hard_variant_benchmark.py
PYTHONPATH=. python scripts/run_causal_controls.py
PYTHONPATH=. python scripts/run_nonlinear_recovery_all.py
PYTHONPATH=. python scripts/run_tcas_ablation.py
PYTHONPATH=. python scripts/run_pca_alternatives.py
PYTHONPATH=. python scripts/run_real_world_analysis.py
PYTHONPATH=. python scripts/run_cka_bootstrap.py
```
